import { afterAll, afterEach, beforeAll } from 'vitest';
import { server } from '../src/mocks/server';
import './mocks/i18next';
import '@testing-library/jest-dom';

beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
